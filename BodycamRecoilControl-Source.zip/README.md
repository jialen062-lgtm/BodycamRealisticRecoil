# Bodycam Recoil Control

独立 Forge 扩展模组，适用于 Minecraft 1.20.1 / Forge 47.2.x / Java 17。

## 依赖

- Bodycam Realistic Recoil 1.0.0 或更新版本
- Timeless & Classics Guns (TaCZ)，由主体模组依赖

## 配置文件

首次启动后生成：`config/bodycamrecoilcontrol-common.toml`

配置项带有中文注释。修改后重新进入世界；如 Forge 未自动重载该配置，重启游戏。

## 主要选项

- 全局、垂直、水平后坐力倍率
- 额外镜头晃动倍率
- 镜头回正速度
- 步枪、冲锋枪、狙击枪、霰弹枪、手枪分类倍率
- 冲刺、蹲下、空中状态倍率

原模组本身的每把枪械基础配置仍然保留；扩展包倍率是在其基础上叠加，不会把枪械手感统一化。
