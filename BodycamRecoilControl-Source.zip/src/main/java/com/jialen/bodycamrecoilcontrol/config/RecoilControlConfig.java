package com.jialen.bodycamrecoilcontrol.config;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.Locale;

public final class RecoilControlConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.DoubleValue GLOBAL_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue VERTICAL_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue HORIZONTAL_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue CAMERA_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue RECOVERY_SPEED;
    public static final ForgeConfigSpec.DoubleValue RIFLE_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue SMG_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue SNIPER_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue SHOTGUN_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue PISTOL_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue SPRINT_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue CROUCH_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue AIRBORNE_MULTIPLIER;
    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.push("recoil_control");

        ENABLED = BUILDER
                .comment("是否启用本扩展包的后坐力调节功能。false = 完全关闭本扩展包的调整。")
                .define("enabled", true);

        GLOBAL_MULTIPLIER = BUILDER
                .comment("全局后坐力倍率。1.0 = 不变；0.5 = 减半；2.0 = 两倍。")
                .defineInRange("globalMultiplier", 1.0D, 0.0D, 5.0D);

        VERTICAL_MULTIPLIER = BUILDER
                .comment("垂直后坐力倍率。数值越大，枪口向上跳动越明显。")
                .defineInRange("verticalMultiplier", 1.0D, 0.0D, 5.0D);

        HORIZONTAL_MULTIPLIER = BUILDER
                .comment("水平后坐力倍率。数值越大，枪口左右偏移越明显。")
                .defineInRange("horizontalMultiplier", 1.0D, 0.0D, 5.0D);

        CAMERA_MULTIPLIER = BUILDER
                .comment("额外镜头后坐力倍率。只调整视角晃动，不改变子弹方向。")
                .defineInRange("cameraMultiplier", 1.0D, 0.0D, 5.0D);

        RECOVERY_SPEED = BUILDER
                .comment("镜头回正速度系数。原版默认值为0.2；数值越大，回正越快；建议0.1到0.5。")
                .defineInRange("recoverySpeed", 0.2D, 0.01D, 1.0D);

        RIFLE_MULTIPLIER = BUILDER.comment("步枪类枪械额外倍率。1.0 = 保持原枪械差异。")
                .defineInRange("rifleMultiplier", 1.0D, 0.0D, 5.0D);
        SMG_MULTIPLIER = BUILDER.comment("冲锋枪类枪械额外倍率。1.0 = 保持原枪械差异。")
                .defineInRange("smgMultiplier", 1.0D, 0.0D, 5.0D);
        SNIPER_MULTIPLIER = BUILDER.comment("狙击枪类枪械额外倍率。1.0 = 保持原枪械差异。")
                .defineInRange("sniperMultiplier", 1.0D, 0.0D, 5.0D);
        SHOTGUN_MULTIPLIER = BUILDER.comment("霰弹枪类枪械额外倍率。1.0 = 保持原枪械差异。")
                .defineInRange("shotgunMultiplier", 1.0D, 0.0D, 5.0D);
        PISTOL_MULTIPLIER = BUILDER.comment("手枪类枪械额外倍率。1.0 = 保持原枪械差异。")
                .defineInRange("pistolMultiplier", 1.0D, 0.0D, 5.0D);

        SPRINT_MULTIPLIER = BUILDER
                .comment("冲刺状态后坐力倍率。当前原模组默认值为1.16。")
                .defineInRange("sprintMultiplier", 1.16D, 0.0D, 5.0D);
        CROUCH_MULTIPLIER = BUILDER
                .comment("蹲下状态后坐力倍率。当前原模组默认值为0.82。")
                .defineInRange("crouchMultiplier", 0.82D, 0.0D, 5.0D);
        AIRBORNE_MULTIPLIER = BUILDER
                .comment("离地/空中状态后坐力倍率。当前原模组默认值为1.18。")
                .defineInRange("airborneMultiplier", 1.18D, 0.0D, 5.0D);

        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    private RecoilControlConfig() { }

    public static boolean enabled() {
        return ENABLED.get();
    }

    public static float globalVertical() {
        return (float) (GLOBAL_MULTIPLIER.get() * VERTICAL_MULTIPLIER.get());
    }

    public static float globalHorizontal() {
        return (float) (GLOBAL_MULTIPLIER.get() * HORIZONTAL_MULTIPLIER.get());
    }

    public static float globalCameraVertical() {
        return (float) (GLOBAL_MULTIPLIER.get() * VERTICAL_MULTIPLIER.get() * CAMERA_MULTIPLIER.get());
    }

    public static float globalCameraHorizontal() {
        return (float) (GLOBAL_MULTIPLIER.get() * HORIZONTAL_MULTIPLIER.get() * CAMERA_MULTIPLIER.get());
    }

    public static float weaponMultiplier(String weaponId) {
        if (weaponId == null) return 1.0F;
        String id = weaponId.toLowerCase(Locale.ROOT);
        if (contains(id, "shotgun", "m870", "m1014", "spas", "aa12", "db")) return SHOTGUN_MULTIPLIER.get().floatValue();
        if (contains(id, "sniper", "bolt", "m24", "awp", "kar98", "mosin", "svd", "dmr")) return SNIPER_MULTIPLIER.get().floatValue();
        if (contains(id, "smg", "mp5", "uzi", "vector", "p90", "ump", "mac10", "mp7")) return SMG_MULTIPLIER.get().floatValue();
        if (contains(id, "pistol", "handgun", "glock", "1911", "deagle", "revolver", "m9")) return PISTOL_MULTIPLIER.get().floatValue();
        return RIFLE_MULTIPLIER.get().floatValue();
    }

    private static boolean contains(String value, String... tokens) {
        for (String token : tokens) {
            if (value.contains(token)) return true;
        }
        return false;
    }
}
