package com.jialen.bodycamrecoilcontrol.mixin;

import com.jialen.bodycamrecoilcontrol.config.RecoilControlConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Pseudo
@Mixin(targets = "com.jialen.bodycamrecoil.client.ClientRecoilHandler", remap = false)
public abstract class ClientRecoilHandlerMixin {
    @ModifyConstant(method = "onClientTick", constant = @Constant(floatValue = 0.2F), remap = false)
    private static float bodycamcontrol$recoverySpeed(float original) {
        return RecoilControlConfig.enabled() ? RecoilControlConfig.RECOVERY_SPEED.get().floatValue() : original;
    }
}
