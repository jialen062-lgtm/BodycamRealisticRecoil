package com.jialen.bodycamrecoilcontrol.mixin;

import com.jialen.bodycamrecoilcontrol.config.RecoilControlConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Pseudo
@Mixin(targets = "com.jialen.bodycamrecoil.recoil.RecoilManager", remap = false)
public abstract class RecoilManagerMixin {
    @ModifyConstant(method = "createShot", constant = @Constant(floatValue = 1.16F), remap = false)
    private static float bodycamcontrol$sprintMultiplier(float original) {
        return RecoilControlConfig.enabled() ? RecoilControlConfig.SPRINT_MULTIPLIER.get().floatValue() : original;
    }

    @ModifyConstant(method = "createShot", constant = @Constant(floatValue = 0.82F, ordinal = 0), remap = false)
    private static float bodycamcontrol$crouchMultiplier(float original) {
        return RecoilControlConfig.enabled() ? RecoilControlConfig.CROUCH_MULTIPLIER.get().floatValue() : original;
    }

    @ModifyConstant(method = "createShot", constant = @Constant(floatValue = 1.18F), remap = false)
    private static float bodycamcontrol$airborneMultiplier(float original) {
        return RecoilControlConfig.enabled() ? RecoilControlConfig.AIRBORNE_MULTIPLIER.get().floatValue() : original;
    }
}
