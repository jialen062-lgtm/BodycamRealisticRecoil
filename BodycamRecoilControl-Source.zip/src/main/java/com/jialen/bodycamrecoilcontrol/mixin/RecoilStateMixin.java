package com.jialen.bodycamrecoilcontrol.mixin;

import com.jialen.bodycamrecoilcontrol.config.RecoilControlConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = "com.jialen.bodycamrecoil.recoil.RecoilState", remap = false)
public abstract class RecoilStateMixin {
    @Inject(method = "pitch", at = @At("RETURN"), cancellable = true, remap = false)
    private void bodycamcontrol$scaleVerticalProjectile(CallbackInfoReturnable<Float> cir) {
        if (RecoilControlConfig.enabled()) {
            cir.setReturnValue(cir.getReturnValue() * RecoilControlConfig.globalVertical());
        }
    }

    @Inject(method = "yaw", at = @At("RETURN"), cancellable = true, remap = false)
    private void bodycamcontrol$scaleHorizontalProjectile(CallbackInfoReturnable<Float> cir) {
        if (RecoilControlConfig.enabled()) {
            cir.setReturnValue(cir.getReturnValue() * RecoilControlConfig.globalHorizontal());
        }
    }

    @Inject(method = "cameraPitch", at = @At("RETURN"), cancellable = true, remap = false)
    private void bodycamcontrol$scaleVerticalCamera(CallbackInfoReturnable<Float> cir) {
        if (RecoilControlConfig.enabled()) {
            cir.setReturnValue(cir.getReturnValue() * RecoilControlConfig.globalCameraVertical());
        }
    }

    @Inject(method = "cameraYaw", at = @At("RETURN"), cancellable = true, remap = false)
    private void bodycamcontrol$scaleHorizontalCamera(CallbackInfoReturnable<Float> cir) {
        if (RecoilControlConfig.enabled()) {
            cir.setReturnValue(cir.getReturnValue() * RecoilControlConfig.globalCameraHorizontal());
        }
    }
}
