package com.jialen.bodycamrecoilcontrol.mixin;

import com.jialen.bodycamrecoilcontrol.config.RecoilControlConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = "com.jialen.bodycamrecoil.recoil.RecoilProfile", remap = false)
public abstract class RecoilProfileMixin {
    @Unique
    private static final ThreadLocal<String> BODYCAM_WEAPON_ID = new ThreadLocal<>();

    @Inject(method = "forWeaponId", at = @At("HEAD"), remap = false)
    private static void bodycamcontrol$captureWeapon(String weaponId, CallbackInfoReturnable<Object> cir) {
        BODYCAM_WEAPON_ID.set(weaponId);
    }

    @Inject(method = "vertical", at = @At("RETURN"), cancellable = true, remap = false)
    private void bodycamcontrol$scaleWeaponVertical(CallbackInfoReturnable<Float> cir) {
        if (RecoilControlConfig.enabled()) {
            cir.setReturnValue(cir.getReturnValue() * RecoilControlConfig.weaponMultiplier(BODYCAM_WEAPON_ID.get()));
        }
    }

    @Inject(method = "horizontal", at = @At("RETURN"), cancellable = true, remap = false)
    private void bodycamcontrol$scaleWeaponHorizontal(CallbackInfoReturnable<Float> cir) {
        if (RecoilControlConfig.enabled()) {
            cir.setReturnValue(cir.getReturnValue() * RecoilControlConfig.weaponMultiplier(BODYCAM_WEAPON_ID.get()));
        }
        BODYCAM_WEAPON_ID.remove();
    }
}
