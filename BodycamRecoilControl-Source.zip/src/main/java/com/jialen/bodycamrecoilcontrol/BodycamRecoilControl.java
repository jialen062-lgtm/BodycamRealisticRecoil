package com.jialen.bodycamrecoilcontrol;

import com.jialen.bodycamrecoilcontrol.config.RecoilControlConfig;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(BodycamRecoilControl.MOD_ID)
public final class BodycamRecoilControl {
    public static final String MOD_ID = "bodycamrecoilcontrol";

    public BodycamRecoilControl() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, RecoilControlConfig.SPEC);
    }
}
