# Bodycam Realistic Recoil

Initial Forge project scaffold for Minecraft 1.20.1 / Java 17.

## Target environment
- Minecraft 1.20.1
- Minecraft Forge 47.2.0
- Java 17
- TaCZ 1.1.8-hotfix2 (optional runtime compatibility target)
- TaCZ Additions is intended to remain optional

## Build
Run with JDK 17 and Gradle 8.x:

```bash
gradle build
```

The output JAR is written to `build/libs/`.

## Current implementation status
This archive is a project scaffold, not a finished gameplay mod.
- Forge mod entry point: present
- Client config: present
- Recoil accumulator data model: present
- TaCZ firing integration: not implemented yet
- Server-authoritative bullet trajectory adjustment: not implemented yet
- Weapon-specific recoil profiles: not implemented yet
- ADS and camera animation: not implemented yet

The TaCZ source inspection identified `ModernKineticGunScriptAPI.shootOnce()` as the firing path where pitch/yaw are passed into `doBulletSpread()`. The next integration step must modify the server-side angles used there, not merely rotate the rendered weapon or camera.
