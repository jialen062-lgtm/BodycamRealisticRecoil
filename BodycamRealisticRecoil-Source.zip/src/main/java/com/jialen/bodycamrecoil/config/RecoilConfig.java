package com.jialen.bodycamrecoil.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class RecoilConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue RECOIL_STRENGTH;
    public static final ForgeConfigSpec.DoubleValue RECOVERY_SPEED;
    public static final ForgeConfigSpec.DoubleValue AIM_RECOIL_MULTIPLIER;
    public static final ForgeConfigSpec.BooleanValue CAMERA_SHAKE;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.push("recoil");
        RECOIL_STRENGTH = builder
                .comment("Overall recoil multiplier. 1.0 is the baseline.")
                .defineInRange("strength", 1.0, 0.0, 5.0);
        RECOVERY_SPEED = builder
                .comment("How quickly accumulated recoil recovers.")
                .defineInRange("recoverySpeed", 0.85, 0.05, 5.0);
        AIM_RECOIL_MULTIPLIER = builder
                .comment("Recoil multiplier while aiming down sights.")
                .defineInRange("aimMultiplier", 0.7, 0.0, 3.0);
        builder.pop();

        builder.push("visual");
        CAMERA_SHAKE = builder
                .comment("Enable camera feedback. This setting is reserved for the client visual layer.")
                .define("cameraShake", true);
        builder.pop();

        SPEC = builder.build();
    }

    private RecoilConfig() {}
}
