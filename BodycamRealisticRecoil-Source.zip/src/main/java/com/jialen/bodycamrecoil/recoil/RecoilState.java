package com.jialen.bodycamrecoil.recoil;

/**
 * Per-player recoil accumulator.
 *
 * This is the initial state model only. It is not yet connected to TaCZ's
 * authoritative server-side bullet creation path.
 */
public final class RecoilState {
    private float pitch;
    private float yaw;

    public void add(float pitchKick, float yawKick) {
        this.pitch += pitchKick;
        this.yaw += yawKick;
    }

    public void recover(float amount) {
        float step = Math.max(0.0F, amount);
        pitch = approachZero(pitch, step);
        yaw = approachZero(yaw, step);
    }

    public float pitch() {
        return pitch;
    }

    public float yaw() {
        return yaw;
    }

    public void reset() {
        pitch = 0.0F;
        yaw = 0.0F;
    }

    private static float approachZero(float value, float step) {
        if (value > 0.0F) return Math.max(0.0F, value - step);
        return Math.min(0.0F, value + step);
    }
}
