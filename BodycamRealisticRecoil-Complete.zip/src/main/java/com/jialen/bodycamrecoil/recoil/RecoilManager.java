package com.jialen.bodycamrecoil.recoil;

import com.jialen.bodycamrecoil.config.RecoilConfig;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class RecoilManager {
    private static final Map<Integer, RecoilState> ACTIVE = new ConcurrentHashMap<>();
    private RecoilManager() {}

    public static RecoilState createShot(ServerPlayer player, ItemStack weapon) {
        if (!RecoilConfig.ENABLED.get() || weapon.isEmpty()) {
            ACTIVE.remove(player.getId());
            return null;
        }
        var registryName = ForgeRegistries.ITEMS.getKey(weapon.getItem());
        String path = registryName == null ? "unknown" : registryName.getPath();
        RecoilProfile profile = RecoilProfile.forWeaponPath(path);
        float stanceScale = player.isSprinting() ? 1.16F : 1.0F;
        if (player.isCrouching()) stanceScale *= 0.82F;
        if (!player.onGround()) stanceScale *= 1.18F;
        float global = RecoilConfig.GLOBAL_MULTIPLIER.get().floatValue() * stanceScale;
        float vertical = profile.vertical() * (0.82F + player.getRandom().nextFloat() * 0.36F) * global;
        float horizontal = (player.getRandom().nextFloat() * 2.0F - 1.0F) * profile.horizontal() * global;
        float cameraScale = RecoilConfig.CAMERA_MULTIPLIER.get().floatValue();
        RecoilState state = new RecoilState(-vertical, horizontal, -vertical * cameraScale,
                horizontal * cameraScale, player.level().getGameTime());
        ACTIVE.put(player.getId(), state);
        return state;
    }

    public static RecoilState get(LivingEntity shooter) {
        RecoilState state = ACTIVE.get(shooter.getId());
        if (state == null) return null;
        if (shooter.level().getGameTime() - state.gameTime() > 2L) {
            ACTIVE.remove(shooter.getId(), state);
            return null;
        }
        return state;
    }
}
