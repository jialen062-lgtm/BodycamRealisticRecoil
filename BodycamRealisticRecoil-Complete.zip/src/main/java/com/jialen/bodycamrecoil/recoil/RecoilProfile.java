package com.jialen.bodycamrecoil.recoil;

public record RecoilProfile(float vertical, float horizontal) {
    public static RecoilProfile forWeaponPath(String path) {
        String id = path.toLowerCase();
        if (containsAny(id, "shotgun", "aa12", "m870", "m1014", "ks23")) return new RecoilProfile(1.65F, 0.52F);
        if (containsAny(id, "sniper", "awm", "m200", "barrett", "bolt")) return new RecoilProfile(2.05F, 0.24F);
        if (containsAny(id, "lmg", "m249", "rpk", "mg42")) return new RecoilProfile(1.30F, 0.48F);
        if (containsAny(id, "smg", "mp5", "mp7", "uzi", "vector")) return new RecoilProfile(0.88F, 0.36F);
        if (containsAny(id, "pistol", "glock", "m1911", "deagle", "revolver")) return new RecoilProfile(0.72F, 0.30F);
        if (containsAny(id, "rifle", "ak", "m4", "scar", "ar15", "famas")) return new RecoilProfile(1.12F, 0.34F);
        return new RecoilProfile(1.0F, 0.32F);
    }
    private static boolean containsAny(String value, String... parts) {
        for (String part : parts) if (value.contains(part)) return true;
        return false;
    }
}
