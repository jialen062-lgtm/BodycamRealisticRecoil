package com.jialen.bodycamrecoil.recoil;

import com.jialen.bodycamrecoil.network.NetworkHandler;
import com.jialen.bodycamrecoil.network.RecoilS2CPacket;
import com.tacz.guns.api.event.common.GunFireEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;

public final class RecoilEventHandler {
    @SubscribeEvent
    public void onGunFire(GunFireEvent event) {
        if (event.getLogicalSide() != LogicalSide.SERVER) return;
        if (!(event.getShooter() instanceof ServerPlayer player)) return;
        RecoilState state = RecoilManager.createShot(player, event.getGunItemStack());
        if (state != null) NetworkHandler.sendToPlayer(player,
                new RecoilS2CPacket(state.cameraPitch(), state.cameraYaw()));
    }
}
