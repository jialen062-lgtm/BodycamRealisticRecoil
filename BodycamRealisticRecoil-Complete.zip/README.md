# Bodycam Realistic Recoil

Minecraft 1.20.1 / Forge 47.2.x / Java 17. Required dependency: TaCZ 1.1.8-hotfix2.

Included source: weapon-path recoil profiles, server-side shot state from TaCZ GunFireEvent, a Mixin intended to adjust the pitch/yaw passed to Projectile.shootFromRotation (actual projectile direction), client camera kick with gradual recovery, and common config values.

No direct dependency on TaCZ Additions is used. Addons sharing AbstractGunItem.doBulletSpread should retain the adjustment; alternate/overridden firing paths need separate compatibility testing.

Build with JDK 17 and Gradle 8.8. Run `gradle clean build`; output is in `build/libs/`.

This source has not yet passed a successful CI build or an in-game test. The Mixin target and runtime behavior must be verified before treating the JAR as release-ready.
