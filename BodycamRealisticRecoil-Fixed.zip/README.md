# Bodycam Realistic Recoil

Minecraft 1.20.1 / Forge / Java 17 / TaCZ 1.1.8-hotfix2

This project is a prototype TaCZ recoil add-on. It prepares a recoil state during
TaCZ's pre-fire event, adjusts the projectile's `shootFromRotation` arguments
through a Mixin, and sends camera feedback when the weapon's current ammo state
indicates that a shot can be fired. The hotfix2 compile artifact does not expose
`GunFirePostEvent`, so the implementation deliberately avoids linking that class.
TaCZ remains authoritative for the actual ammo check and projectile creation.

Weapon profiles are selected from TaCZ's actual gun resource ID via
`IGun.getGunId(ItemStack)`, not the shared registered item ID.

## Build

Use Java 17 and Gradle 8.8:

```bash
gradle --no-daemon clean build
```

The output JAR is in `build/libs/`.

## Important testing status

A successful Gradle build only confirms compilation and packaging. It does not
prove that the Mixin applies in a running game or that the camera and projectile
motion feel correct. Test in Minecraft 1.20.1 with Forge and TaCZ 1.1.8-hotfix2.
Check single fire, automatic fire, empty magazines, chambered rounds, scoped
aiming, and any TaCZ Additions content separately. The camera ammo pre-check is
conservative and may not exactly mirror every custom scripted weapon's ammo rules.

This is not yet a verified release build.
