# Bodycam Realistic Recoil

Minecraft 1.20.1 / Forge / Java 17 / TaCZ 1.1.8-hotfix2

This project is a prototype TaCZ recoil add-on. It prepares a recoil state during
TaCZ's pre-fire event, adjusts the projectile's `shootFromRotation` arguments
through a Mixin, and sends the matching camera kick only after TaCZ confirms a
successful shot with `GunFirePostEvent`.

Weapon profiles are selected from TaCZ's actual gun resource ID via
`IGun.getGunId(ItemStack)`, not the shared registered item ID.

## Build

Use Java 17 and Gradle 8.8:

```bash
gradle --no-daemon clean build
```

The output JAR is in `build/libs/`.

## Important testing status

A successful Gradle build only confirms compilation and packaging. It does not
prove that the Mixin applies in a running game or that the camera and projectile
motion feel correct. Test in Minecraft 1.20.1 with Forge and TaCZ 1.1.8-hotfix2.
Check single fire, automatic fire, empty magazines, scoped aiming, and any
TaCZ Additions content separately.

This is not yet a verified release build.
