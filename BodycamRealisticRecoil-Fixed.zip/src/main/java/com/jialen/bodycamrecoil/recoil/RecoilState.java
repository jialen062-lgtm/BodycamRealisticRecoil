package com.jialen.bodycamrecoil.recoil;

public record RecoilState(float pitch, float yaw, float cameraPitch, float cameraYaw, long gameTime) {}
