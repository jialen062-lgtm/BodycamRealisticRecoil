package com.jialen.bodycamrecoil.recoil;

import com.jialen.bodycamrecoil.config.RecoilConfig;
import com.tacz.guns.api.item.IGun;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class RecoilManager {
    private static final Map<Integer, RecoilState> ACTIVE = new ConcurrentHashMap<>();

    private RecoilManager() {}

    /**
     * Called from TaCZ's pre-fire event. The state is immediately consumed by
     * AbstractGunItem.doBulletSpread and confirmed/cleared by GunFirePostEvent.
     */
    public static RecoilState createShot(ServerPlayer player, ItemStack weapon) {
        if (!RecoilConfig.ENABLED.get() || weapon.isEmpty()) {
            ACTIVE.remove(player.getId());
            return null;
        }

        IGun gun = IGun.getIGunOrNull(weapon);
        if (gun == null) {
            ACTIVE.remove(player.getId());
            return null;
        }

        String gunId = gun.getGunId(weapon).toString();
        RecoilProfile profile = RecoilProfile.forWeaponId(gunId);

        float stanceScale = player.isSprinting() ? 1.16F : 1.0F;
        if (player.isCrouching()) stanceScale *= 0.82F;
        if (!player.onGround()) stanceScale *= 1.18F;

        float global = RecoilConfig.GLOBAL_MULTIPLIER.get().floatValue() * stanceScale;
        float vertical = profile.vertical()
                * (0.82F + player.getRandom().nextFloat() * 0.36F) * global;
        float horizontal = (player.getRandom().nextFloat() * 2.0F - 1.0F)
                * profile.horizontal() * global;
        float cameraScale = RecoilConfig.CAMERA_MULTIPLIER.get().floatValue();

        RecoilState state = new RecoilState(
                -vertical, horizontal,
                -vertical * cameraScale, horizontal * cameraScale,
                player.level().getGameTime());
        ACTIVE.put(player.getId(), state);
        return state;
    }

    /** Read without removing: the projectile hook and post-fire event both need it. */
    public static RecoilState get(LivingEntity shooter) {
        RecoilState state = ACTIVE.get(shooter.getId());
        if (state == null) return null;

        // Prevent a cancelled/failed shot from leaving recoil state for a later shot.
        if (shooter.level().getGameTime() - state.gameTime() > 0L) {
            ACTIVE.remove(shooter.getId(), state);
            return null;
        }
        return state;
    }

    /** Called only after TaCZ confirms a successful shot. */
    public static RecoilState finishShot(LivingEntity shooter) {
        RecoilState state = ACTIVE.remove(shooter.getId());
        if (state == null) return null;
        if (shooter.level().getGameTime() != state.gameTime()) return null;
        return state;
    }
}
