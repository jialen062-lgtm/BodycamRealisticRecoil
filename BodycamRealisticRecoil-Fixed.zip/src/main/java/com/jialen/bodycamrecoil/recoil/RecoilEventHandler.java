package com.jialen.bodycamrecoil.recoil;

import com.jialen.bodycamrecoil.network.NetworkHandler;
import com.jialen.bodycamrecoil.network.RecoilS2CPacket;
import com.tacz.guns.api.event.common.GunFireEvent;
import com.tacz.guns.api.item.IGun;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;

public final class RecoilEventHandler {
    /**
     * TaCZ 1.1.8 hotfix compile artifacts do not expose GunFirePostEvent.
     * Keep this handler on the supported pre-fire event and only send visual
     * feedback when the weapon currently appears capable of consuming a shot.
     * The same recoil state remains available to the projectile Mixin.
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onGunFire(GunFireEvent event) {
        if (event.getLogicalSide() != LogicalSide.SERVER || event.isCanceled()) return;
        if (!(event.getShooter() instanceof ServerPlayer player)) return;

        ItemStack weapon = event.getGunItemStack();
        RecoilState state = RecoilManager.createShot(player, weapon);
        if (state == null || !hasPotentialAmmo(player, weapon)) return;

        NetworkHandler.sendToPlayer(player,
                new RecoilS2CPacket(state.cameraPitch(), state.cameraYaw()));
    }

    private static boolean hasPotentialAmmo(ServerPlayer player, ItemStack weapon) {
        IGun gun = IGun.getIGunOrNull(weapon);
        if (gun == null) return false;

        // TaCZ supports both magazine-fed and inventory-fed weapons, plus a
        // chambered round. This is a conservative visual check; TaCZ itself
        // remains responsible for the authoritative ammo validation.
        if (gun.useInventoryAmmo(weapon)) {
            return gun.hasInventoryAmmo(player, weapon, true);
        }
        return gun.getCurrentAmmoCount(weapon) > 0 || gun.hasBulletInBarrel(weapon);
    }
}
