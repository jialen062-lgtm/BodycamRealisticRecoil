package com.jialen.bodycamrecoil.recoil;

import com.jialen.bodycamrecoil.network.NetworkHandler;
import com.jialen.bodycamrecoil.network.RecoilS2CPacket;
import com.tacz.guns.api.event.common.GunFireEvent;
import com.tacz.guns.api.event.common.GunFirePostEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;

public final class RecoilEventHandler {
    @SubscribeEvent
    public void onGunFire(GunFireEvent event) {
        if (event.getLogicalSide() != LogicalSide.SERVER) return;
        if (!(event.getShooter() instanceof ServerPlayer player)) return;

        // Prepare the per-shot recoil before TaCZ calculates projectile direction.
        // Do not send camera feedback here: TaCZ fires this event before ammo checks.
        RecoilManager.createShot(player, event.getGunItemStack());
    }

    @SubscribeEvent
    public void onGunFirePost(GunFirePostEvent event) {
        if (event.getLogicalSide() != LogicalSide.SERVER) return;
        if (!(event.getShooter() instanceof ServerPlayer player)) return;

        // Post event is emitted only after a projectile was successfully created.
        RecoilState state = RecoilManager.finishShot(player);
        if (state != null) {
            NetworkHandler.sendToPlayer(player,
                    new RecoilS2CPacket(state.cameraPitch(), state.cameraYaw()));
        }
    }
}
