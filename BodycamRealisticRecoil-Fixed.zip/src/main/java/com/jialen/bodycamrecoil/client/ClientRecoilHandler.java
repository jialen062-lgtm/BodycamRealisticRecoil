package com.jialen.bodycamrecoil.client;

import com.jialen.bodycamrecoil.BodycamRecoil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = BodycamRecoil.MOD_ID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientRecoilHandler {
    private static float returnPitch;
    private static float returnYaw;
    private ClientRecoilHandler() {}

    public static void kick(float pitch, float yaw) {
        Player player = Minecraft.getInstance().player;
        if (player == null) return;
        player.setXRot(player.getXRot() + pitch);
        player.setYRot(player.getYRot() + yaw);
        player.setYHeadRot(player.getYRot());
        returnPitch += pitch;
        returnYaw += yaw;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Player player = Minecraft.getInstance().player;
        if (player == null) { returnPitch = 0.0F; returnYaw = 0.0F; return; }
        float pitchStep = returnPitch * 0.20F;
        float yawStep = returnYaw * 0.20F;
        player.setXRot(player.getXRot() - pitchStep);
        player.setYRot(player.getYRot() - yawStep);
        player.setYHeadRot(player.getYRot());
        returnPitch -= pitchStep;
        returnYaw -= yawStep;
        if (Math.abs(returnPitch) < 0.01F) returnPitch = 0.0F;
        if (Math.abs(returnYaw) < 0.01F) returnYaw = 0.0F;
    }
}
