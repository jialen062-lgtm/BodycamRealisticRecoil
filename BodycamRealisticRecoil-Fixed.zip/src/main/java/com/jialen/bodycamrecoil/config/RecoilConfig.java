package com.jialen.bodycamrecoil.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class RecoilConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.DoubleValue GLOBAL_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue CAMERA_MULTIPLIER;
    public static final ForgeConfigSpec SPEC;
    static {
        BUILDER.push("recoil");
        ENABLED = BUILDER.comment("Enable Bodycam recoil.").define("enabled", true);
        GLOBAL_MULTIPLIER = BUILDER.comment("Global recoil strength. 1.0 is default.")
                .defineInRange("globalMultiplier", 1.0D, 0.0D, 4.0D);
        CAMERA_MULTIPLIER = BUILDER.comment("Visual camera kick relative to projectile recoil.")
                .defineInRange("cameraMultiplier", 1.0D, 0.0D, 3.0D);
        BUILDER.pop();
        SPEC = BUILDER.build();
    }
    private RecoilConfig() {}
}
