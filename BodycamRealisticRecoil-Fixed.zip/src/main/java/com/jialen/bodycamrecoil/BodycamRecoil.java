package com.jialen.bodycamrecoil;

import com.jialen.bodycamrecoil.config.RecoilConfig;
import com.jialen.bodycamrecoil.network.NetworkHandler;
import com.jialen.bodycamrecoil.recoil.RecoilEventHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(BodycamRecoil.MOD_ID)
public final class BodycamRecoil {
    public static final String MOD_ID = "bodycamrecoil";
    public BodycamRecoil() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, RecoilConfig.SPEC);
        NetworkHandler.register();
        MinecraftForge.EVENT_BUS.register(new RecoilEventHandler());
    }
}
