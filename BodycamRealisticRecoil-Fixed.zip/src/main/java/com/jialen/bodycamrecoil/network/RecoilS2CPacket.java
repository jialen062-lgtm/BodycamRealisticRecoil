package com.jialen.bodycamrecoil.network;

import com.jialen.bodycamrecoil.client.ClientRecoilHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public final class RecoilS2CPacket {
    private final float pitch;
    private final float yaw;
    public RecoilS2CPacket(float pitch, float yaw) { this.pitch = pitch; this.yaw = yaw; }
    public static void encode(RecoilS2CPacket packet, FriendlyByteBuf buffer) {
        buffer.writeFloat(packet.pitch); buffer.writeFloat(packet.yaw);
    }
    public static RecoilS2CPacket decode(FriendlyByteBuf buffer) {
        return new RecoilS2CPacket(buffer.readFloat(), buffer.readFloat());
    }
    public static void handle(RecoilS2CPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientRecoilHandler.kick(packet.pitch, packet.yaw)));
        context.setPacketHandled(true);
    }
}
