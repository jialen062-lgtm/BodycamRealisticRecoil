package com.jialen.bodycamrecoil.network;

import com.jialen.bodycamrecoil.BodycamRecoil;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class NetworkHandler {
    private static final String PROTOCOL = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(BodycamRecoil.MOD_ID, "main"), () -> PROTOCOL,
            PROTOCOL::equals, PROTOCOL::equals);
    private static boolean registered;
    private NetworkHandler() {}
    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.registerMessage(0, RecoilS2CPacket.class, RecoilS2CPacket::encode,
                RecoilS2CPacket::decode, RecoilS2CPacket::handle);
    }
    public static void sendToPlayer(ServerPlayer player, RecoilS2CPacket packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
}
