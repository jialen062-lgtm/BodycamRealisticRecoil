package com.jialen.bodycamrecoil.mixin;

import com.jialen.bodycamrecoil.recoil.RecoilManager;
import com.jialen.bodycamrecoil.recoil.RecoilState;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Pseudo
@Mixin(targets = "com.tacz.guns.api.item.gun.AbstractGunItem")
public abstract class AbstractGunItemMixin {
    @ModifyArgs(method = "doBulletSpread", remap = false,
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/projectile/Projectile;shootFromRotation(Lnet/minecraft/world/entity/Entity;FFFFF)V",
                    remap = true))
    private void bodycam$applyRealProjectileRecoil(Args args) {
        Object shooter = args.get(0);
        if (!(shooter instanceof LivingEntity livingEntity)) return;
        RecoilState recoil = RecoilManager.get(livingEntity);
        if (recoil == null) return;
        args.set(1, ((Float) args.get(1)) + recoil.pitch());
        args.set(2, ((Float) args.get(2)) + recoil.yaw());
    }
}
